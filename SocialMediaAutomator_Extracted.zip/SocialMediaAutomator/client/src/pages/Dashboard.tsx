import { useState } from "react";
import Sidebar from "@/components/Sidebar";
import MobileHeader from "@/components/MobileHeader";
import PlatformConnections from "@/components/PlatformConnections";
import AutomationStatus from "@/components/AutomationStatus";
import ActivityTimeline from "@/components/ActivityTimeline";
import EarningsSummary from "@/components/EarningsSummary";
import SetupModal from "@/components/SetupModal";
import QuickStartGuide from "@/components/QuickStartGuide";

export default function Dashboard() {
  const [isSidebarVisible, setIsSidebarVisible] = useState(false);
  const [isSetupModalOpen, setIsSetupModalOpen] = useState(false);
  
  const toggleSidebar = () => {
    setIsSidebarVisible(!isSidebarVisible);
  };
  
  const openSetupModal = () => {
    setIsSetupModalOpen(true);
  };
  
  return (
    <div className="flex h-screen overflow-hidden bg-gray-50 text-gray-800">
      {/* Sidebar */}
      <Sidebar 
        isVisible={isSidebarVisible} 
        onClose={() => setIsSidebarVisible(false)} 
      />
      
      {/* Mobile header */}
      <MobileHeader onMenuToggle={toggleSidebar} />
      
      {/* Main content */}
      <main className="flex-1 overflow-y-auto pt-16 md:pt-0">
        <div className="p-6">
          <div className="mb-8">
            <h2 className="text-2xl font-semibold text-gray-800">Dashboard</h2>
            <p className="text-gray-600 mt-1">Monitor your automated social media activities</p>
          </div>

          {/* Platform Connection Status */}
          <PlatformConnections />

          {/* Automation Status */}
          <AutomationStatus />

          {/* Recent Activity & Analytics */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Recent Activity */}
            <ActivityTimeline />

            {/* Earnings Summary */}
            <EarningsSummary />
          </div>
        </div>
      </main>
      
      {/* Setup Modal */}
      <SetupModal
        open={isSetupModalOpen}
        onOpenChange={setIsSetupModalOpen}
      />
      
      {/* Quick Start Guide */}
      <QuickStartGuide onStartSetup={openSetupModal} />
    </div>
  );
}
