import { useQuery } from "@tanstack/react-query";
import { EarningsSummary as EarningsSummaryType, platformIcons } from "@/lib/types";
import { Progress } from "@/components/ui/progress";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function EarningsSummary() {
  const { data: earningsSummary, isLoading } = useQuery<EarningsSummaryType>({
    queryKey: ['/api/earnings/summary'],
  });
  
  if (isLoading) {
    return <EarningsSummarySkeleton />;
  }
  
  // Calculate percentages for progress bars
  const total = parseFloat(earningsSummary?.total || "0");
  const summaryWithPercentage = earningsSummary?.summary.map(item => ({
    ...item,
    percentage: Math.round((parseFloat(item.amount) / total) * 100) || 0
  })) || [];
  
  // Sort by amount descending
  summaryWithPercentage.sort((a, b) => parseFloat(b.amount) - parseFloat(a.amount));
  
  // Add Facebook with 0 if it doesn't exist
  if (!summaryWithPercentage.find(item => item.platform === 'facebook')) {
    summaryWithPercentage.push({
      platform: 'facebook',
      amount: '0.00',
      percentage: 0
    });
  }
  
  const formatDate = (daysAhead: number) => {
    const date = new Date();
    date.setDate(date.getDate() + daysAhead);
    return date.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
  };
  
  return (
    <div>
      <h3 className="text-lg font-medium text-gray-800 mb-4">Earnings Summary</h3>
      <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
        <div className="p-5">
          <div className="text-center mb-6">
            <p className="text-sm text-gray-600">Total Earnings (This Month)</p>
            <h4 className="text-3xl font-bold text-gray-900 mt-1">${earningsSummary?.total || "0.00"}</h4>
            <p className="text-xs text-success flex items-center justify-center mt-1">
              <span className="material-icons text-xs mr-1">arrow_upward</span>
              <span>23% from last month</span>
            </p>
          </div>
          
          <div className="space-y-4">
            {summaryWithPercentage.map((item) => {
              const { icon, bgColor, textColor } = platformIcons[item.platform] || {};
              const isDisabled = parseFloat(item.amount) === 0;
              
              return (
                <div 
                  key={item.platform} 
                  className={`bg-gray-50 p-3 rounded-lg ${isDisabled ? 'opacity-60' : ''}`}
                >
                  <div className="flex justify-between items-center mb-2">
                    <div className="flex items-center">
                      <span className={`w-6 h-6 rounded-full ${bgColor} flex items-center justify-center mr-2`}>
                        <span className={`material-icons ${textColor} text-xs`}>{icon}</span>
                      </span>
                      <span className="text-sm font-medium text-gray-700">
                        {item.platform.charAt(0).toUpperCase() + item.platform.slice(1)}
                      </span>
                    </div>
                    <span className="text-sm font-bold text-gray-900">${item.amount}</span>
                  </div>
                  <Progress value={item.percentage} className="h-1.5" />
                  {item.platform === 'facebook' && parseFloat(item.amount) === 0 && (
                    <p className="text-xs text-gray-500 mt-1">Reconnect to enable monetization</p>
                  )}
                </div>
              );
            })}
          </div>
          
          <div className="mt-6 pt-4 border-t border-gray-200">
            <h5 className="text-sm font-medium text-gray-700 mb-3">Next Bank Transfer</h5>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">{formatDate(5)}</span>
              <span className="text-sm font-bold text-gray-900">${earningsSummary?.total || "0.00"}</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">Automatic weekly transfer enabled</p>
          </div>
        </div>
        
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <Button variant="link" className="w-full flex items-center justify-center">
            View earnings details
            <span className="material-icons ml-1 text-sm">arrow_forward</span>
          </Button>
        </div>
      </div>
    </div>
  );
}

function EarningsSummarySkeleton() {
  return (
    <div>
      <h3 className="text-lg font-medium text-gray-800 mb-4">Earnings Summary</h3>
      <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
        <div className="p-5">
          <div className="text-center mb-6">
            <Skeleton className="h-4 w-48 mx-auto mb-2" />
            <Skeleton className="h-8 w-24 mx-auto mb-2" />
            <Skeleton className="h-3 w-32 mx-auto" />
          </div>
          
          <div className="space-y-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="bg-gray-50 p-3 rounded-lg">
                <div className="flex justify-between items-center mb-2">
                  <div className="flex items-center">
                    <Skeleton className="w-6 h-6 rounded-full mr-2" />
                    <Skeleton className="h-4 w-20" />
                  </div>
                  <Skeleton className="h-4 w-16" />
                </div>
                <Skeleton className="h-1.5 w-full rounded-full" />
              </div>
            ))}
          </div>
          
          <div className="mt-6 pt-4 border-t border-gray-200">
            <Skeleton className="h-4 w-48 mb-3" />
            <div className="flex justify-between items-center mb-2">
              <Skeleton className="h-4 w-24" />
              <Skeleton className="h-4 w-16" />
            </div>
            <Skeleton className="h-3 w-56" />
          </div>
        </div>
        
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <Skeleton className="h-5 w-48 mx-auto" />
        </div>
      </div>
    </div>
  );
}
