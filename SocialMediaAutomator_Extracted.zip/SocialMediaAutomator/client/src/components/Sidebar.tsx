import { Link, useLocation } from "wouter";

interface SidebarProps {
  isVisible: boolean;
  onClose?: () => void;
}

export default function Sidebar({ isVisible, onClose }: SidebarProps) {
  const [location] = useLocation();

  const navItems = [
    { path: "/", label: "Dashboard", icon: "dashboard" },
    { path: "/automation", label: "Automation", icon: "auto_awesome" },
    { path: "/history", label: "Activity History", icon: "history" },
    { path: "/earnings", label: "Earnings", icon: "attach_money" },
    { path: "/settings", label: "Settings", icon: "settings" },
  ];

  const sidebarClassName = `
    ${isVisible ? "fixed inset-0 z-50 block" : "hidden"} 
    md:flex md:flex-col md:w-64 md:static md:z-auto
    bg-white border-r border-gray-200
  `;

  return (
    <aside className={sidebarClassName}>
      <div className="flex items-center justify-center h-16 border-b border-gray-200">
        <h1 className="text-xl font-bold text-primary">AI Automation Tool</h1>
      </div>
      
      <div className="overflow-y-auto flex-grow">
        <nav className="mt-5 px-2">
          {navItems.map((item) => {
            const isActive = location === item.path;
            const baseClasses = "flex items-center px-4 py-3 mt-1 text-sm font-medium rounded-md group";
            const activeClasses = "text-primary bg-indigo-50";
            const inactiveClasses = "text-gray-600 hover:text-primary hover:bg-indigo-50 sidebar-icon";
            const iconBaseClasses = "mr-3";
            const iconActiveClasses = "text-primary";
            const iconInactiveClasses = "text-gray-500 group-hover:text-primary";
            
            return (
              <Link 
                key={item.path} 
                href={item.path} 
                onClick={onClose}
                className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
              >
                <span className={`material-icons ${iconBaseClasses} ${isActive ? iconActiveClasses : iconInactiveClasses}`}>
                  {item.icon}
                </span>
                <span>{item.label}</span>
              </Link>
            );
          })}
        </nav>
      </div>
      
      <div className="border-t border-gray-200 p-4">
        <div className="flex items-center">
          <div className="flex-shrink-0 h-8 w-8 rounded-full bg-primary flex items-center justify-center text-white">
            <span>U</span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-gray-700">User</p>
            <p className="text-xs font-medium text-gray-500">user@example.com</p>
          </div>
        </div>
      </div>
    </aside>
  );
}
