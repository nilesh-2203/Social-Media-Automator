import { useQuery } from "@tanstack/react-query";
import { AutomationConfig } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { TrendingTopics } from "@/lib/types";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function AutomationStatus() {
  const { data: config, isLoading: configLoading } = useQuery<AutomationConfig>({
    queryKey: ['/api/automation-config'],
  });
  
  const { data: trendingTopics, isLoading: topicsLoading } = useQuery<TrendingTopics>({
    queryKey: ['/api/trending-topics'],
  });
  
  if (configLoading) {
    return <AutomationStatusSkeleton />;
  }
  
  return (
    <section className="mb-8">
      <h3 className="text-lg font-medium text-gray-800 mb-4">Automation Status</h3>
      <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
        <div className="p-5">
          <div className="flex items-center justify-between mb-4">
            <h4 className="text-lg font-medium">Content Generation</h4>
            <div className="flex items-center">
              <span className="flex h-3 w-3 relative">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-success opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-success"></span>
              </span>
              <span className="ml-2 text-sm font-medium text-success">Active</span>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="font-medium text-gray-700">Daily Posts</div>
                <div className="text-secondary font-bold">1/day</div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Automated content generation daily</p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="font-medium text-gray-700">Next Post</div>
                <div className="text-primary font-bold">
                  {getRandomTimeRemaining()}
                </div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Time until next automated post</p>
            </div>
            
            <div className="bg-gray-50 rounded-lg p-4">
              <div className="flex items-center justify-between">
                <div className="font-medium text-gray-700">Success Rate</div>
                <div className="text-success font-bold">92%</div>
              </div>
              <p className="text-xs text-gray-500 mt-1">Last 30 days posting success</p>
            </div>
          </div>
          
          <div className="mt-6">
            <h5 className="font-medium text-gray-700 mb-3">Current Trending Topics</h5>
            {topicsLoading ? (
              <div className="flex flex-wrap gap-2">
                {Array(4).fill(0).map((_, i) => (
                  <Skeleton key={i} className="h-6 w-28 rounded-full" />
                ))}
              </div>
            ) : (
              <div className="flex flex-wrap gap-2">
                {trendingTopics?.topics.map((topic, index) => (
                  <Badge key={index} variant="outline" className="bg-indigo-100 text-primary hover:bg-indigo-200">
                    {topic}
                  </Badge>
                ))}
              </div>
            )}
          </div>
        </div>
        
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <div className="flex justify-between items-center">
            <div className="flex items-center">
              <Badge className="bg-success text-white hover:bg-success mr-2">
                Auto-Mode
              </Badge>
              <span className="text-sm text-gray-600">
                Next payment transfer: 5 days
              </span>
            </div>
            <Button>Configure</Button>
          </div>
        </div>
      </div>
    </section>
  );
}

function getRandomTimeRemaining() {
  const hours = Math.floor(Math.random() * 12);
  const minutes = Math.floor(Math.random() * 60);
  return `${hours}h ${minutes}m`;
}

function AutomationStatusSkeleton() {
  return (
    <section className="mb-8">
      <h3 className="text-lg font-medium text-gray-800 mb-4">Automation Status</h3>
      <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
        <div className="p-5">
          <div className="flex items-center justify-between mb-4">
            <Skeleton className="h-6 w-48" />
            <Skeleton className="h-4 w-16" />
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {Array(3).fill(0).map((_, i) => (
              <div key={i} className="bg-gray-50 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <Skeleton className="h-4 w-24" />
                  <Skeleton className="h-4 w-12" />
                </div>
                <Skeleton className="h-3 w-full" />
              </div>
            ))}
          </div>
          
          <div className="mt-6">
            <Skeleton className="h-5 w-48 mb-3" />
            <div className="flex flex-wrap gap-2">
              {Array(4).fill(0).map((_, i) => (
                <Skeleton key={i} className="h-6 w-28 rounded-full" />
              ))}
            </div>
          </div>
        </div>
        
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <div className="flex justify-between items-center">
            <Skeleton className="h-5 w-48" />
            <Skeleton className="h-9 w-24" />
          </div>
        </div>
      </div>
    </section>
  );
}
