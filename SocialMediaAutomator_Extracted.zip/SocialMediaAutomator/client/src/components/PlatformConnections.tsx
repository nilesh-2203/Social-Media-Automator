import { useQuery, useMutation } from "@tanstack/react-query";
import { Platform, platformIcons } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { Skeleton } from "@/components/ui/skeleton";

export default function PlatformConnections() {
  const { data: platforms, isLoading } = useQuery<Platform[]>({
    queryKey: ['/api/platform-connections'],
  });
  
  return (
    <section className="mb-8">
      <h3 className="text-lg font-medium text-gray-800 mb-4">Platform Connections</h3>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {isLoading ? (
          Array(3).fill(0).map((_, i) => (
            <PlatformCardSkeleton key={i} />
          ))
        ) : (
          platforms?.map((platform) => (
            <PlatformCard key={platform.id} platform={platform} />
          ))
        )}
      </div>
    </section>
  );
}

interface PlatformCardProps {
  platform: Platform;
}

function PlatformCard({ platform }: PlatformCardProps) {
  const platformName = platform.platform.charAt(0).toUpperCase() + platform.platform.slice(1);
  const { icon, bgColor, textColor } = platformIcons[platform.platform] || {
    icon: "help_outline",
    bgColor: "bg-gray-100",
    textColor: "text-gray-600"
  };
  
  const formatDate = (date: Date | undefined) => {
    if (!date) return "Never";
    
    const now = new Date();
    const diff = now.getTime() - new Date(date).getTime();
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const days = Math.floor(hours / 24);
    
    if (days > 0) {
      return `${days} day${days > 1 ? 's' : ''} ago`;
    } else if (hours > 0) {
      return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    } else {
      return "Just now";
    }
  };
  
  const configMutation = useMutation({
    mutationFn: () => {
      return apiRequest('PUT', `/api/platform-connections/${platform.id}`, {
        isConnected: !platform.isConnected
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/platform-connections'] });
    }
  });
  
  return (
    <div className="platform-card bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
      <div className="p-5">
        <div className="flex items-center">
          <div className={`w-10 h-10 rounded-full ${bgColor} flex items-center justify-center`}>
            <span className={`material-icons ${textColor}`}>{icon}</span>
          </div>
          <div className="ml-3">
            <h4 className="text-md font-medium text-gray-800">{platformName}</h4>
            <div className="flex items-center mt-1">
              {platform.isConnected ? (
                <>
                  <span className="h-2 w-2 bg-success rounded-full"></span>
                  <span className="text-xs ml-1 text-success font-medium">Connected</span>
                </>
              ) : (
                <>
                  <span className="h-2 w-2 bg-warning rounded-full"></span>
                  <span className="text-xs ml-1 text-warning font-medium">Reconnect Needed</span>
                </>
              )}
            </div>
          </div>
        </div>
        <div className="mt-4 text-sm text-gray-600">
          <p>Last post: <span>{formatDate(platform.lastPostTime)}</span></p>
          <p>Scheduled posts: <span>{Math.floor(Math.random() * 4)}</span></p>
        </div>
      </div>
      <div className="bg-gray-50 px-5 py-3 border-t border-gray-200">
        <Button 
          variant="ghost" 
          size="sm" 
          className="text-xs text-gray-600 hover:text-primary flex items-center p-0"
          onClick={() => configMutation.mutate()}
          disabled={configMutation.isPending}
        >
          <span className="material-icons text-xs mr-1">settings</span>
          Configure
        </Button>
      </div>
    </div>
  );
}

function PlatformCardSkeleton() {
  return (
    <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
      <div className="p-5">
        <div className="flex items-center">
          <Skeleton className="w-10 h-10 rounded-full" />
          <div className="ml-3">
            <Skeleton className="h-4 w-24 mb-2" />
            <Skeleton className="h-3 w-16" />
          </div>
        </div>
        <div className="mt-4">
          <Skeleton className="h-3 w-40 mb-2" />
          <Skeleton className="h-3 w-32" />
        </div>
      </div>
      <div className="bg-gray-50 px-5 py-3 border-t border-gray-200">
        <Skeleton className="h-4 w-20" />
      </div>
    </div>
  );
}
