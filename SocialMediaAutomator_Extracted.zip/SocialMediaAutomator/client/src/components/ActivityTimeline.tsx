import { useQuery } from "@tanstack/react-query";
import { ActivityLog } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export default function ActivityTimeline() {
  const { data: logs, isLoading } = useQuery<ActivityLog[]>({
    queryKey: ['/api/activity-logs'],
  });
  
  const getLinkForType = (type: string): { icon: string, color: string } => {
    switch (type) {
      case 'success':
        return { icon: 'check', color: 'bg-success' };
      case 'warning':
        return { icon: 'warning', color: 'bg-warning' };
      case 'earnings':
        return { icon: 'attach_money', color: 'bg-primary' };
      default:
        return { icon: 'info', color: 'bg-primary' };
    }
  };
  
  const formatTimeAgo = (timestamp: Date) => {
    const now = new Date();
    const logDate = new Date(timestamp);
    const diffMs = now.getTime() - logDate.getTime();
    const diffHrs = Math.floor(diffMs / (1000 * 60 * 60));
    
    if (diffHrs < 24) {
      return `${diffHrs}h ago`;
    } else {
      const diffDays = Math.floor(diffHrs / 24);
      return `${diffDays}d ago`;
    }
  };
  
  return (
    <div className="lg:col-span-2">
      <h3 className="text-lg font-medium text-gray-800 mb-4">Recent Activity</h3>
      <div className="bg-white rounded-lg shadow-md overflow-hidden border border-gray-200">
        <div className="p-5">
          <div className="flow-root">
            <ul className="-mb-8">
              {isLoading ? (
                Array(4).fill(0).map((_, i) => (
                  <ActivityItemSkeleton key={i} isLast={i === 3} />
                ))
              ) : (
                logs?.map((log, index) => {
                  const { icon, color } = getLinkForType(log.type);
                  const isLast = index === logs.length - 1;
                  
                  return (
                    <li key={log.id}>
                      <div className="relative pb-8">
                        {!isLast && (
                          <span 
                            className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" 
                            aria-hidden="true"
                          />
                        )}
                        <div className="relative flex space-x-3">
                          <div>
                            <span className={`h-8 w-8 rounded-full ${color} flex items-center justify-center ring-8 ring-white`}>
                              <span className="material-icons text-white text-sm">{icon}</span>
                            </span>
                          </div>
                          <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
                            <div>
                              <p className="text-sm text-gray-700" dangerouslySetInnerHTML={{ __html: log.message }} />
                              {log.details && (
                                <p className="text-xs text-gray-500 mt-1">{log.details}</p>
                              )}
                            </div>
                            <div className="text-right text-xs whitespace-nowrap text-gray-500">
                              <time dateTime={log.timestamp.toString()}>
                                {formatTimeAgo(log.timestamp)}
                              </time>
                            </div>
                          </div>
                        </div>
                      </div>
                    </li>
                  );
                })
              )}
            </ul>
          </div>
        </div>
        <div className="border-t border-gray-200 p-4 bg-gray-50">
          <Button variant="link" className="w-full flex items-center justify-center">
            View all activity
            <span className="material-icons ml-1 text-sm">arrow_forward</span>
          </Button>
        </div>
      </div>
    </div>
  );
}

interface ActivityItemSkeletonProps {
  isLast: boolean;
}

function ActivityItemSkeleton({ isLast }: ActivityItemSkeletonProps) {
  return (
    <li>
      <div className="relative pb-8">
        {!isLast && (
          <span 
            className="absolute top-4 left-4 -ml-px h-full w-0.5 bg-gray-200" 
            aria-hidden="true"
          />
        )}
        <div className="relative flex space-x-3">
          <div>
            <Skeleton className="h-8 w-8 rounded-full" />
          </div>
          <div className="min-w-0 flex-1 pt-1.5 flex justify-between space-x-4">
            <div className="w-full">
              <Skeleton className="h-4 w-3/4 mb-2" />
              <Skeleton className="h-3 w-1/2" />
            </div>
            <div className="text-right">
              <Skeleton className="h-3 w-10" />
            </div>
          </div>
        </div>
      </div>
    </li>
  );
}
