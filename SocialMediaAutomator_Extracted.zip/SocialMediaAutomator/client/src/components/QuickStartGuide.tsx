import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardFooter } from "@/components/ui/card";

interface QuickStartGuideProps {
  onStartSetup: () => void;
}

export default function QuickStartGuide({ onStartSetup }: QuickStartGuideProps) {
  const [isVisible, setIsVisible] = useState(false);
  
  // Check if user has dismissed the guide before
  useEffect(() => {
    const hasSeenGuide = localStorage.getItem('hasSeenGuide');
    if (!hasSeenGuide) {
      const timer = setTimeout(() => {
        setIsVisible(true);
      }, 1500);
      
      return () => clearTimeout(timer);
    }
  }, []);
  
  const handleDismiss = () => {
    setIsVisible(false);
  };
  
  const handleDontShowAgain = () => {
    localStorage.setItem('hasSeenGuide', 'true');
    setIsVisible(false);
  };
  
  const handleStartSetup = () => {
    setIsVisible(false);
    onStartSetup();
  };
  
  if (!isVisible) return null;
  
  return (
    <div className="fixed bottom-5 right-5 max-w-sm z-40">
      <Card className="border border-gray-200 shadow-xl overflow-hidden">
        <CardHeader className="bg-primary text-white p-4 flex justify-between items-center">
          <h3 className="font-medium">Quick Start Guide</h3>
          <Button 
            variant="ghost" 
            size="icon" 
            className="text-white hover:bg-primary/90 h-7 w-7 p-0" 
            onClick={handleDismiss}
          >
            <span className="material-icons">close</span>
          </Button>
        </CardHeader>
        
        <CardContent className="p-4">
          <ol className="space-y-4 text-sm">
            <li className="flex items-start">
              <span className="flex-shrink-0 w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center mr-2 mt-0.5">1</span>
              <div>
                <h4 className="font-medium text-gray-900">Connect Your Platforms</h4>
                <p className="text-gray-600 mt-1">Enter your API keys for YouTube, Instagram, and Facebook.</p>
              </div>
            </li>
            
            <li className="flex items-start">
              <span className="flex-shrink-0 w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center mr-2 mt-0.5">2</span>
              <div>
                <h4 className="font-medium text-gray-900">Set Up Automation</h4>
                <p className="text-gray-600 mt-1">Configure when and how often content should be generated and posted.</p>
              </div>
            </li>
            
            <li className="flex items-start">
              <span className="flex-shrink-0 w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center mr-2 mt-0.5">3</span>
              <div>
                <h4 className="font-medium text-gray-900">Add Bank Details</h4>
                <p className="text-gray-600 mt-1">Enter your bank account information for automatic earnings transfers.</p>
              </div>
            </li>
            
            <li className="flex items-start">
              <span className="flex-shrink-0 w-6 h-6 bg-primary text-white rounded-full flex items-center justify-center mr-2 mt-0.5">4</span>
              <div>
                <h4 className="font-medium text-gray-900">Sit Back & Relax</h4>
                <p className="text-gray-600 mt-1">The AI will now automatically generate, post content, and transfer earnings.</p>
              </div>
            </li>
          </ol>
        </CardContent>
        
        <CardFooter className="border-t border-gray-200 flex justify-between p-4">
          <Button variant="ghost" size="sm" onClick={handleDontShowAgain}>
            Don't show again
          </Button>
          <Button size="sm" onClick={handleStartSetup}>
            Start Setup
          </Button>
        </CardFooter>
      </Card>
    </div>
  );
}
