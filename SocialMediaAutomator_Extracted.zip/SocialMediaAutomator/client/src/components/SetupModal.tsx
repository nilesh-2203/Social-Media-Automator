import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { useForm } from "react-hook-form";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

interface SetupModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface FormValues {
  youtubeApiKey: string;
  instagramApiKey: string;
  facebookApiKey: string;
  bankAccount: string;
  dailyPosts: boolean;
  weeklyTransfers: boolean;
  emailNotifications: boolean;
}

export default function SetupModal({ open, onOpenChange }: SetupModalProps) {
  const [showYoutubePassword, setShowYoutubePassword] = useState(false);
  const [showInstagramPassword, setShowInstagramPassword] = useState(false);
  const [showFacebookPassword, setShowFacebookPassword] = useState(false);
  const { toast } = useToast();
  
  const { register, handleSubmit, formState } = useForm<FormValues>({
    defaultValues: {
      youtubeApiKey: "",
      instagramApiKey: "",
      facebookApiKey: "",
      bankAccount: "",
      dailyPosts: true,
      weeklyTransfers: true,
      emailNotifications: true,
    }
  });
  
  const platformMutation = useMutation({
    mutationFn: async (data: FormValues) => {
      // Create array of platform data
      const platforms = [
        { platform: 'youtube', apiKey: data.youtubeApiKey },
        { platform: 'instagram', apiKey: data.instagramApiKey },
        { platform: 'facebook', apiKey: data.facebookApiKey }
      ];
      
      // Filter out empty API keys
      const validPlatforms = platforms.filter(p => p.apiKey.trim() !== '');
      
      // Save all platforms with valid API keys
      const results = await Promise.all(
        validPlatforms.map(platform => 
          apiRequest('POST', '/api/platform-connections', platform)
        )
      );
      
      // Save automation config
      await apiRequest('POST', '/api/automation-config', {
        dailyPostsEnabled: data.dailyPosts,
        weeklyTransfersEnabled: data.weeklyTransfers,
        emailNotificationsEnabled: data.emailNotifications,
        bankAccountNumber: data.bankAccount,
      });
      
      return results;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/platform-connections'] });
      queryClient.invalidateQueries({ queryKey: ['/api/automation-config'] });
      
      toast({
        title: "Setup successful!",
        description: "Your platforms have been connected and automation is active.",
      });
      
      onOpenChange(false);
    },
    onError: (error) => {
      toast({
        title: "Setup failed",
        description: "There was an error connecting your platforms. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  const onSubmit = (data: FormValues) => {
    platformMutation.mutate(data);
  };
  
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Connect Social Media Platforms</DialogTitle>
        </DialogHeader>
        
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="py-4">
            <p className="text-sm text-gray-600 mb-6">Enter your API keys for each platform to enable automated posting.</p>
            
            <div className="space-y-5">
              {/* YouTube API */}
              <div>
                <Label htmlFor="youtubeApiKey" className="block text-sm font-medium text-gray-700 mb-1">
                  YouTube API Key
                </Label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <Input
                    id="youtubeApiKey"
                    type={showYoutubePassword ? "text" : "password"}
                    placeholder="Enter your YouTube API key"
                    {...register("youtubeApiKey")}
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button
                      type="button"
                      onClick={() => setShowYoutubePassword(!showYoutubePassword)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <span className="material-icons">
                        {showYoutubePassword ? "visibility" : "visibility_off"}
                      </span>
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-xs text-gray-500">Your YouTube data API key from Google Cloud Console</p>
              </div>
              
              {/* Instagram API */}
              <div>
                <Label htmlFor="instagramApiKey" className="block text-sm font-medium text-gray-700 mb-1">
                  Instagram API Key
                </Label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <Input
                    id="instagramApiKey"
                    type={showInstagramPassword ? "text" : "password"}
                    placeholder="Enter your Instagram API key"
                    {...register("instagramApiKey")}
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button
                      type="button"
                      onClick={() => setShowInstagramPassword(!showInstagramPassword)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <span className="material-icons">
                        {showInstagramPassword ? "visibility" : "visibility_off"}
                      </span>
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-xs text-gray-500">Your Instagram Graph API key from Facebook Developer Portal</p>
              </div>
              
              {/* Facebook API */}
              <div>
                <Label htmlFor="facebookApiKey" className="block text-sm font-medium text-gray-700 mb-1">
                  Facebook API Key
                </Label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <Input
                    id="facebookApiKey"
                    type={showFacebookPassword ? "text" : "password"}
                    placeholder="Enter your Facebook API key"
                    {...register("facebookApiKey")}
                  />
                  <div className="absolute inset-y-0 right-0 pr-3 flex items-center">
                    <button
                      type="button"
                      onClick={() => setShowFacebookPassword(!showFacebookPassword)}
                      className="text-gray-400 hover:text-gray-500"
                    >
                      <span className="material-icons">
                        {showFacebookPassword ? "visibility" : "visibility_off"}
                      </span>
                    </button>
                  </div>
                </div>
                <p className="mt-1 text-xs text-gray-500">Your Facebook Graph API key from Facebook Developer Portal</p>
              </div>
              
              {/* Bank Account */}
              <div>
                <Label htmlFor="bankAccount" className="block text-sm font-medium text-gray-700 mb-1">
                  Bank Account Number (Optional)
                </Label>
                <Input
                  id="bankAccount"
                  type="text"
                  placeholder="For automatic earnings transfers"
                  {...register("bankAccount")}
                />
                <p className="mt-1 text-xs text-gray-500">For automatically transferring your earnings</p>
              </div>
              
              {/* Automation Settings */}
              <div className="pt-4 border-t border-gray-200">
                <h4 className="text-sm font-medium text-gray-900 mb-3">Automation Settings</h4>
                
                <div className="flex items-center mb-3">
                  <Checkbox id="dailyPosts" {...register("dailyPosts")} />
                  <Label htmlFor="dailyPosts" className="ml-2 text-sm text-gray-700">
                    Enable daily content generation and posting
                  </Label>
                </div>
                
                <div className="flex items-center mb-3">
                  <Checkbox id="weeklyTransfers" {...register("weeklyTransfers")} />
                  <Label htmlFor="weeklyTransfers" className="ml-2 text-sm text-gray-700">
                    Enable weekly automatic earnings transfers
                  </Label>
                </div>
                
                <div className="flex items-center">
                  <Checkbox id="emailNotifications" {...register("emailNotifications")} />
                  <Label htmlFor="emailNotifications" className="ml-2 text-sm text-gray-700">
                    Receive email notifications for important events
                  </Label>
                </div>
              </div>
            </div>
          </div>
          
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={platformMutation.isPending}>
              {platformMutation.isPending ? 'Saving...' : 'Save & Connect'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
