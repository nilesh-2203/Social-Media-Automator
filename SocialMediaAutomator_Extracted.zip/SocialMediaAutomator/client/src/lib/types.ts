// Platform types
export interface Platform {
  id: number;
  platform: string;
  apiKey: string;
  isConnected: boolean;
  lastPostTime?: Date;
  userId: number;
}

// Automation config type
export interface AutomationConfig {
  id: number;
  dailyPostsEnabled: boolean;
  weeklyTransfersEnabled: boolean;
  emailNotificationsEnabled: boolean;
  bankAccountNumber?: string;
  userId: number;
}

// Activity log type
export interface ActivityLog {
  id: number;
  type: string;
  message: string;
  details?: string;
  timestamp: Date;
  userId: number;
}

// Earnings type
export interface Earning {
  id: number;
  platform: string;
  amount: string;
  timestamp: Date;
  transferred: boolean;
  userId: number;
}

// Earnings summary type
export interface EarningsSummary {
  summary: {
    platform: string;
    amount: string;
  }[];
  total: string;
}

// Trending topics
export interface TrendingTopics {
  topics: string[];
}

// Platform icon mappings
export const platformIcons: Record<string, { icon: string; bgColor: string; textColor: string }> = {
  youtube: {
    icon: "smart_display",
    bgColor: "bg-red-100",
    textColor: "text-red-600"
  },
  instagram: {
    icon: "photo_camera",
    bgColor: "bg-purple-100",
    textColor: "text-purple-600"
  },
  facebook: {
    icon: "facebook",
    bgColor: "bg-blue-100",
    textColor: "text-blue-600"
  }
};
