import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

// Platform connections
export const platformConnections = pgTable("platform_connections", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(), // 'youtube', 'instagram', 'facebook'
  apiKey: text("api_key").notNull(),
  isConnected: boolean("is_connected").notNull().default(true),
  lastPostTime: timestamp("last_post_time"),
  userId: integer("user_id").notNull(),
});

export const insertPlatformConnectionSchema = createInsertSchema(platformConnections).pick({
  platform: true,
  apiKey: true,
  userId: true,
});

export type InsertPlatformConnection = z.infer<typeof insertPlatformConnectionSchema>;
export type PlatformConnection = typeof platformConnections.$inferSelect;

// Automation configuration
export const automationConfig = pgTable("automation_config", {
  id: serial("id").primaryKey(),
  dailyPostsEnabled: boolean("daily_posts_enabled").notNull().default(true),
  weeklyTransfersEnabled: boolean("weekly_transfers_enabled").notNull().default(true),
  emailNotificationsEnabled: boolean("email_notifications_enabled").notNull().default(true),
  bankAccountNumber: text("bank_account_number"),
  userId: integer("user_id").notNull(),
});

export const insertAutomationConfigSchema = createInsertSchema(automationConfig).pick({
  dailyPostsEnabled: true,
  weeklyTransfersEnabled: true,
  emailNotificationsEnabled: true,
  bankAccountNumber: true,
  userId: true,
});

export type InsertAutomationConfig = z.infer<typeof insertAutomationConfigSchema>;
export type AutomationConfig = typeof automationConfig.$inferSelect;

// Activity logs
export const activityLogs = pgTable("activity_logs", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(), // 'post', 'warning', 'earnings', etc.
  message: text("message").notNull(),
  details: text("details"),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  userId: integer("user_id").notNull(),
});

export const insertActivityLogSchema = createInsertSchema(activityLogs).pick({
  type: true,
  message: true,
  details: true,
  userId: true,
});

export type InsertActivityLog = z.infer<typeof insertActivityLogSchema>;
export type ActivityLog = typeof activityLogs.$inferSelect;

// Earnings records
export const earnings = pgTable("earnings", {
  id: serial("id").primaryKey(),
  platform: text("platform").notNull(), // 'youtube', 'instagram', 'facebook'
  amount: text("amount").notNull(), // Stored as string to handle currency precision
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  transferred: boolean("transferred").notNull().default(false),
  userId: integer("user_id").notNull(),
});

export const insertEarningSchema = createInsertSchema(earnings).pick({
  platform: true,
  amount: true,
  userId: true,
});

export type InsertEarning = z.infer<typeof insertEarningSchema>;
export type Earning = typeof earnings.$inferSelect;
