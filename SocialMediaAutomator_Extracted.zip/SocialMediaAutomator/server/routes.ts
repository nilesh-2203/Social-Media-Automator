import express, { type Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertPlatformConnectionSchema, 
  insertAutomationConfigSchema, 
  insertActivityLogSchema,
  insertEarningSchema
} from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = express.Router();

  // Get current user (for demo purposes, return user with ID 1)
  apiRouter.get("/user", async (_req, res) => {
    const user = await storage.getUser(1);
    
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }
    
    // Don't return password in response
    const { password, ...userWithoutPassword } = user;
    res.json(userWithoutPassword);
  });

  // Platform Connections
  apiRouter.get("/platform-connections", async (_req, res) => {
    // For demo, use user with ID 1
    const userId = 1;
    const connections = await storage.getPlatformConnections(userId);
    res.json(connections);
  });

  apiRouter.post("/platform-connections", async (req, res) => {
    try {
      const userId = 1; // For demo
      const data = insertPlatformConnectionSchema.parse({
        ...req.body,
        userId,
      });
      
      // Check if connection already exists for this platform
      const existingConnection = await storage.getPlatformConnectionByType(userId, data.platform);
      
      if (existingConnection) {
        // Update existing connection
        const updated = await storage.updatePlatformConnection(existingConnection.id, {
          apiKey: data.apiKey,
          isConnected: true,
        });
        
        if (!updated) {
          return res.status(404).json({ message: "Failed to update platform connection" });
        }
        
        return res.json(updated);
      }
      
      // Create new connection
      const connection = await storage.createPlatformConnection(data);
      
      // Log activity
      await storage.createActivityLog({
        type: "connection",
        message: `Connected to ${data.platform}`,
        details: `API key updated for ${data.platform}`,
        userId
      });
      
      res.status(201).json(connection);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid platform connection data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to create platform connection" });
    }
  });

  apiRouter.put("/platform-connections/:id", async (req, res) => {
    try {
      const userId = 1; // For demo
      const id = parseInt(req.params.id);
      
      // Validate that the connection belongs to the user
      const existingConnection = await storage.getPlatformConnection(id);
      if (!existingConnection || existingConnection.userId !== userId) {
        return res.status(404).json({ message: "Platform connection not found" });
      }
      
      const updated = await storage.updatePlatformConnection(id, req.body);
      
      if (!updated) {
        return res.status(404).json({ message: "Failed to update platform connection" });
      }
      
      res.json(updated);
    } catch (error) {
      res.status(500).json({ message: "Failed to update platform connection" });
    }
  });

  // Automation Config
  apiRouter.get("/automation-config", async (_req, res) => {
    try {
      const userId = 1; // For demo
      let config = await storage.getAutomationConfig(userId);
      
      if (!config) {
        // Create default config if none exists
        config = await storage.createAutomationConfig({
          userId,
          dailyPostsEnabled: true,
          weeklyTransfersEnabled: true,
          emailNotificationsEnabled: true,
          bankAccountNumber: "",
        });
      }
      
      res.json(config);
    } catch (error) {
      res.status(500).json({ message: "Failed to get automation config" });
    }
  });

  apiRouter.post("/automation-config", async (req, res) => {
    try {
      const userId = 1; // For demo
      const data = insertAutomationConfigSchema.parse({
        ...req.body,
        userId,
      });
      
      let config = await storage.getAutomationConfig(userId);
      
      if (config) {
        // Update existing config
        config = await storage.updateAutomationConfig(userId, data);
        
        if (!config) {
          return res.status(404).json({ message: "Failed to update automation config" });
        }
      } else {
        // Create new config
        config = await storage.createAutomationConfig(data);
      }
      
      // Log activity
      await storage.createActivityLog({
        type: "config",
        message: "Automation settings updated",
        details: "Updated automation configuration",
        userId
      });
      
      res.json(config);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid automation config data", errors: error.errors });
      }
      res.status(500).json({ message: "Failed to save automation config" });
    }
  });

  // Activity Logs
  apiRouter.get("/activity-logs", async (req, res) => {
    try {
      const userId = 1; // For demo
      const limit = req.query.limit ? parseInt(req.query.limit as string) : undefined;
      const logs = await storage.getActivityLogs(userId, limit);
      res.json(logs);
    } catch (error) {
      res.status(500).json({ message: "Failed to get activity logs" });
    }
  });

  // Earnings
  apiRouter.get("/earnings", async (_req, res) => {
    try {
      const userId = 1; // For demo
      const earnings = await storage.getEarnings(userId);
      res.json(earnings);
    } catch (error) {
      res.status(500).json({ message: "Failed to get earnings" });
    }
  });

  apiRouter.get("/earnings/summary", async (_req, res) => {
    try {
      const userId = 1; // For demo
      const summary = await storage.getEarningsSummary(userId);
      const total = await storage.getTotalEarnings(userId);
      
      res.json({
        summary,
        total
      });
    } catch (error) {
      res.status(500).json({ message: "Failed to get earnings summary" });
    }
  });

  // Get trending topics (simulated data since we can't connect to actual AI API)
  apiRouter.get("/trending-topics", async (_req, res) => {
    res.json({
      topics: [
        "#AITechnology",
        "#DigitalMarketing",
        "#PassiveIncome",
        "#SocialMediaTips"
      ]
    });
  });

  // Initialize demo data
  await initDemoData();

  // Mount API router
  app.use("/api", apiRouter);

  const httpServer = createServer(app);
  return httpServer;
}

// Initialize demo data for the app
async function initDemoData() {
  const userId = 1;

  // Setup demo platform connections
  const youtube = await storage.getPlatformConnectionByType(userId, 'youtube');
  if (!youtube) {
    await storage.createPlatformConnection({
      platform: 'youtube',
      apiKey: process.env.YOUTUBE_API_KEY || '',
      userId,
    });
  }

  const instagram = await storage.getPlatformConnectionByType(userId, 'instagram');
  if (!instagram) {
    await storage.createPlatformConnection({
      platform: 'instagram',
      apiKey: process.env.INSTAGRAM_API_KEY || '',
      userId,
    });
  }

  const facebook = await storage.getPlatformConnectionByType(userId, 'facebook');
  if (!facebook) {
    await storage.createPlatformConnection({
      platform: 'facebook',
      apiKey: process.env.FACEBOOK_API_KEY || '',
      userId,
    });

    // Update facebook to need reconnection
    const fb = await storage.getPlatformConnectionByType(userId, 'facebook');
    if (fb) {
      await storage.updatePlatformConnection(fb.id, { isConnected: false });
    }
  }

  // Setup automation config
  const config = await storage.getAutomationConfig(userId);
  if (!config) {
    await storage.createAutomationConfig({
      userId,
      dailyPostsEnabled: true,
      weeklyTransfersEnabled: true,
      emailNotificationsEnabled: true,
      bankAccountNumber: "",
    });
  }

  // Add some demo activity logs
  const logs = await storage.getActivityLogs(userId);
  if (logs.length === 0) {
    // Video posted
    await storage.createActivityLog({
      type: 'success',
      message: 'Video posted to YouTube and Instagram',
      details: 'AI generated content on #AITechnology',
      userId
    });

    // Facebook warning
    await storage.createActivityLog({
      type: 'warning',
      message: 'Facebook API connection needs renewal',
      details: 'Token expired or revoked',
      userId
    });

    // Earnings
    await storage.createActivityLog({
      type: 'earnings',
      message: 'Earnings from YouTube - $127.35',
      details: 'Automatically transferred to bank account',
      userId
    });

    // Trending
    await storage.createActivityLog({
      type: 'success',
      message: 'YouTube video reached 10,000 views',
      details: 'Video on "Passive Income with AI"',
      userId
    });
  }

  // Add some demo earnings
  const earningsList = await storage.getEarnings(userId);
  if (earningsList.length === 0) {
    await storage.createEarning({
      platform: 'youtube',
      amount: '312.45',
      userId
    });

    await storage.createEarning({
      platform: 'instagram',
      amount: '115.38',
      userId
    });
  }
}
