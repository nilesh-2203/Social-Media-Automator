import { 
  User, InsertUser, users,
  PlatformConnection, InsertPlatformConnection, platformConnections,
  AutomationConfig, InsertAutomationConfig, automationConfig,
  ActivityLog, InsertActivityLog, activityLogs,
  Earning, InsertEarning, earnings
} from "@shared/schema";

// Extend the storage interface with our CRUD methods
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Platform connection methods
  getPlatformConnections(userId: number): Promise<PlatformConnection[]>;
  getPlatformConnection(id: number): Promise<PlatformConnection | undefined>;
  getPlatformConnectionByType(userId: number, platform: string): Promise<PlatformConnection | undefined>;
  createPlatformConnection(connection: InsertPlatformConnection): Promise<PlatformConnection>;
  updatePlatformConnection(id: number, data: Partial<PlatformConnection>): Promise<PlatformConnection | undefined>;
  deletePlatformConnection(id: number): Promise<boolean>;
  
  // Automation config methods
  getAutomationConfig(userId: number): Promise<AutomationConfig | undefined>;
  createAutomationConfig(config: InsertAutomationConfig): Promise<AutomationConfig>;
  updateAutomationConfig(userId: number, data: Partial<AutomationConfig>): Promise<AutomationConfig | undefined>;
  
  // Activity log methods
  getActivityLogs(userId: number, limit?: number): Promise<ActivityLog[]>;
  createActivityLog(log: InsertActivityLog): Promise<ActivityLog>;
  
  // Earnings methods
  getEarnings(userId: number): Promise<Earning[]>;
  getEarningsByPlatform(userId: number, platform: string): Promise<Earning[]>;
  createEarning(earning: InsertEarning): Promise<Earning>;
  updateEarning(id: number, data: Partial<Earning>): Promise<Earning | undefined>;
  getEarningsSummary(userId: number): Promise<{ platform: string, amount: string }[]>;
  getTotalEarnings(userId: number): Promise<string>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private platformConnections: Map<number, PlatformConnection>;
  private automationConfigs: Map<number, AutomationConfig>;
  private activityLogs: Map<number, ActivityLog>;
  private earningsData: Map<number, Earning>;
  private currentId: { [key: string]: number };

  constructor() {
    this.users = new Map();
    this.platformConnections = new Map();
    this.automationConfigs = new Map();
    this.activityLogs = new Map();
    this.earningsData = new Map();
    this.currentId = {
      users: 1,
      platformConnections: 1,
      automationConfigs: 1,
      activityLogs: 1,
      earnings: 1
    };

    // Add demo user
    this.createUser({ username: "demo", password: "demo" });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId.users++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  // Platform connection methods
  async getPlatformConnections(userId: number): Promise<PlatformConnection[]> {
    return Array.from(this.platformConnections.values()).filter(
      (connection) => connection.userId === userId
    );
  }

  async getPlatformConnection(id: number): Promise<PlatformConnection | undefined> {
    return this.platformConnections.get(id);
  }

  async getPlatformConnectionByType(userId: number, platform: string): Promise<PlatformConnection | undefined> {
    return Array.from(this.platformConnections.values()).find(
      (connection) => connection.userId === userId && connection.platform === platform
    );
  }

  async createPlatformConnection(insertConnection: InsertPlatformConnection): Promise<PlatformConnection> {
    const id = this.currentId.platformConnections++;
    const now = new Date();
    const connection: PlatformConnection = { 
      ...insertConnection, 
      id, 
      isConnected: true, 
      lastPostTime: insertConnection.platform === 'facebook' ? null : now 
    };
    this.platformConnections.set(id, connection);
    return connection;
  }

  async updatePlatformConnection(id: number, data: Partial<PlatformConnection>): Promise<PlatformConnection | undefined> {
    const connection = this.platformConnections.get(id);
    if (!connection) return undefined;
    
    const updatedConnection = { ...connection, ...data };
    this.platformConnections.set(id, updatedConnection);
    return updatedConnection;
  }

  async deletePlatformConnection(id: number): Promise<boolean> {
    return this.platformConnections.delete(id);
  }

  // Automation config methods
  async getAutomationConfig(userId: number): Promise<AutomationConfig | undefined> {
    return Array.from(this.automationConfigs.values()).find(
      (config) => config.userId === userId
    );
  }

  async createAutomationConfig(insertConfig: InsertAutomationConfig): Promise<AutomationConfig> {
    const id = this.currentId.automationConfigs++;
    const config: AutomationConfig = { ...insertConfig, id };
    this.automationConfigs.set(id, config);
    return config;
  }

  async updateAutomationConfig(userId: number, data: Partial<AutomationConfig>): Promise<AutomationConfig | undefined> {
    const config = Array.from(this.automationConfigs.values()).find(
      (config) => config.userId === userId
    );
    
    if (!config) return undefined;
    
    const updatedConfig = { ...config, ...data };
    this.automationConfigs.set(config.id, updatedConfig);
    return updatedConfig;
  }

  // Activity log methods
  async getActivityLogs(userId: number, limit?: number): Promise<ActivityLog[]> {
    const logs = Array.from(this.activityLogs.values())
      .filter((log) => log.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
    
    return limit ? logs.slice(0, limit) : logs;
  }

  async createActivityLog(insertLog: InsertActivityLog): Promise<ActivityLog> {
    const id = this.currentId.activityLogs++;
    const log: ActivityLog = { 
      ...insertLog, 
      id, 
      timestamp: new Date() 
    };
    this.activityLogs.set(id, log);
    return log;
  }

  // Earnings methods
  async getEarnings(userId: number): Promise<Earning[]> {
    return Array.from(this.earningsData.values())
      .filter((earning) => earning.userId === userId)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async getEarningsByPlatform(userId: number, platform: string): Promise<Earning[]> {
    return Array.from(this.earningsData.values())
      .filter((earning) => earning.userId === userId && earning.platform === platform)
      .sort((a, b) => b.timestamp.getTime() - a.timestamp.getTime());
  }

  async createEarning(insertEarning: InsertEarning): Promise<Earning> {
    const id = this.currentId.earnings++;
    const earning: Earning = { 
      ...insertEarning, 
      id, 
      timestamp: new Date(),
      transferred: false
    };
    this.earningsData.set(id, earning);
    return earning;
  }

  async updateEarning(id: number, data: Partial<Earning>): Promise<Earning | undefined> {
    const earning = this.earningsData.get(id);
    if (!earning) return undefined;
    
    const updatedEarning = { ...earning, ...data };
    this.earningsData.set(id, updatedEarning);
    return updatedEarning;
  }

  async getEarningsSummary(userId: number): Promise<{ platform: string, amount: string }[]> {
    const userEarnings = await this.getEarnings(userId);
    
    const summary: { [platform: string]: number } = {};
    
    for (const earning of userEarnings) {
      const platform = earning.platform;
      const amount = parseFloat(earning.amount);
      
      if (!summary[platform]) {
        summary[platform] = 0;
      }
      
      summary[platform] += amount;
    }
    
    return Object.entries(summary).map(([platform, amount]) => ({
      platform,
      amount: amount.toFixed(2)
    }));
  }

  async getTotalEarnings(userId: number): Promise<string> {
    const userEarnings = await this.getEarnings(userId);
    
    const total = userEarnings.reduce((sum, earning) => {
      return sum + parseFloat(earning.amount);
    }, 0);
    
    return total.toFixed(2);
  }
}

export const storage = new MemStorage();
